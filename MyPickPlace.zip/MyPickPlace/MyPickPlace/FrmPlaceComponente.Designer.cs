﻿namespace MyPickPlace
{
    partial class FrmPlaceComponente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox7 = new GroupBox();
            NumPosY = new NumericUpDown();
            groupBox5 = new GroupBox();
            NumPosX = new NumericUpDown();
            groupBox3 = new GroupBox();
            CmbPosiciones = new ComboBox();
            groupBox1 = new GroupBox();
            TxtDescripcion = new TextBox();
            groupBox8 = new GroupBox();
            NumRotacion = new NumericUpDown();
            CmdAceptar = new Button();
            groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NumPosY).BeginInit();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NumPosX).BeginInit();
            groupBox3.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NumRotacion).BeginInit();
            SuspendLayout();
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(NumPosY);
            groupBox7.Location = new Point(156, 88);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(117, 70);
            groupBox7.TabIndex = 11;
            groupBox7.TabStop = false;
            groupBox7.Text = "Posicion Y";
            // 
            // NumPosY
            // 
            NumPosY.DecimalPlaces = 1;
            NumPosY.Location = new Point(24, 27);
            NumPosY.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            NumPosY.Name = "NumPosY";
            NumPosY.Size = new Size(78, 23);
            NumPosY.TabIndex = 2;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(NumPosX);
            groupBox5.Location = new Point(12, 88);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(127, 70);
            groupBox5.TabIndex = 10;
            groupBox5.TabStop = false;
            groupBox5.Text = "Posicion X";
            // 
            // NumPosX
            // 
            NumPosX.DecimalPlaces = 1;
            NumPosX.Location = new Point(24, 27);
            NumPosX.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            NumPosX.Name = "NumPosX";
            NumPosX.Size = new Size(78, 23);
            NumPosX.TabIndex = 2;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(CmbPosiciones);
            groupBox3.Location = new Point(12, 187);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(422, 70);
            groupBox3.TabIndex = 8;
            groupBox3.TabStop = false;
            groupBox3.Text = "Situacion Componente";
            // 
            // CmbPosiciones
            // 
            CmbPosiciones.FormattingEnabled = true;
            CmbPosiciones.Location = new Point(25, 22);
            CmbPosiciones.Name = "CmbPosiciones";
            CmbPosiciones.Size = new Size(375, 23);
            CmbPosiciones.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(TxtDescripcion);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(422, 70);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Descripcion";
            // 
            // TxtDescripcion
            // 
            TxtDescripcion.Location = new Point(15, 34);
            TxtDescripcion.Name = "TxtDescripcion";
            TxtDescripcion.Size = new Size(401, 23);
            TxtDescripcion.TabIndex = 0;
            // 
            // groupBox8
            // 
            groupBox8.Controls.Add(NumRotacion);
            groupBox8.Location = new Point(289, 88);
            groupBox8.Name = "groupBox8";
            groupBox8.Size = new Size(117, 70);
            groupBox8.TabIndex = 12;
            groupBox8.TabStop = false;
            groupBox8.Text = "Rotación";
            // 
            // NumRotacion
            // 
            NumRotacion.DecimalPlaces = 1;
            NumRotacion.Location = new Point(24, 27);
            NumRotacion.Maximum = new decimal(new int[] { 360, 0, 0, 0 });
            NumRotacion.Name = "NumRotacion";
            NumRotacion.Size = new Size(78, 23);
            NumRotacion.TabIndex = 2;
            // 
            // CmdAceptar
            // 
            CmdAceptar.Location = new Point(353, 300);
            CmdAceptar.Name = "CmdAceptar";
            CmdAceptar.Size = new Size(75, 23);
            CmdAceptar.TabIndex = 13;
            CmdAceptar.Text = "Ok";
            CmdAceptar.UseVisualStyleBackColor = true;
            CmdAceptar.Click += CmdAceptar_Click;
            // 
            // FrmPlaceComponente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(449, 335);
            Controls.Add(CmdAceptar);
            Controls.Add(groupBox8);
            Controls.Add(groupBox7);
            Controls.Add(groupBox5);
            Controls.Add(groupBox3);
            Controls.Add(groupBox1);
            Name = "FrmPlaceComponente";
            Text = "Configurar";
            Load += FrmPlaceComponente_Load;
            groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)NumPosY).EndInit();
            groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)NumPosX).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)NumRotacion).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox7;
        private NumericUpDown NumPosY;
        private GroupBox groupBox5;
        private NumericUpDown NumPosX;
        private GroupBox groupBox3;
        private ComboBox CmbPosiciones;
        private GroupBox groupBox1;
        private TextBox TxtDescripcion;
        private GroupBox groupBox8;
        private NumericUpDown NumRotacion;
        private Button CmdAceptar;
    }
}