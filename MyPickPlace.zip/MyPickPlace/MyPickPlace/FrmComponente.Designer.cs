﻿namespace MyPickPlace
{
    partial class FrmComponente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            TxtDescripcion = new TextBox();
            groupBox2 = new GroupBox();
            ChkPresion = new CheckBox();
            groupBox3 = new GroupBox();
            CmbPrecision = new ComboBox();
            groupBox4 = new GroupBox();
            label1 = new Label();
            NumSpeed = new NumericUpDown();
            groupBox5 = new GroupBox();
            NumNozzle = new NumericUpDown();
            groupBox6 = new GroupBox();
            TxtPosicion = new TextBox();
            CmdOk = new Button();
            groupBox7 = new GroupBox();
            NumAltura = new NumericUpDown();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NumSpeed).BeginInit();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NumNozzle).BeginInit();
            groupBox6.SuspendLayout();
            groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)NumAltura).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(TxtDescripcion);
            groupBox1.Location = new Point(12, 24);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(422, 70);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Descripcion";
            // 
            // TxtDescripcion
            // 
            TxtDescripcion.Location = new Point(15, 34);
            TxtDescripcion.Name = "TxtDescripcion";
            TxtDescripcion.Size = new Size(401, 23);
            TxtDescripcion.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(ChkPresion);
            groupBox2.Location = new Point(12, 100);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(422, 70);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Presion";
            // 
            // ChkPresion
            // 
            ChkPresion.AutoSize = true;
            ChkPresion.Location = new Point(15, 22);
            ChkPresion.Name = "ChkPresion";
            ChkPresion.Size = new Size(276, 19);
            ChkPresion.TabIndex = 0;
            ChkPresion.Text = "Activar bomba presion para coger componente";
            ChkPresion.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(CmbPrecision);
            groupBox3.Location = new Point(12, 176);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(422, 70);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Precision colocacion";
            // 
            // CmbPrecision
            // 
            CmbPrecision.FormattingEnabled = true;
            CmbPrecision.Items.AddRange(new object[] { "None", "Quick", "Accurate" });
            CmbPrecision.Location = new Point(25, 22);
            CmbPrecision.Name = "CmbPrecision";
            CmbPrecision.Size = new Size(375, 23);
            CmbPrecision.TabIndex = 0;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(label1);
            groupBox4.Controls.Add(NumSpeed);
            groupBox4.Location = new Point(12, 252);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(422, 70);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "Velocidad";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(109, 24);
            label1.Name = "label1";
            label1.Size = new Size(121, 15);
            label1.TabIndex = 1;
            label1.Text = "% velocidad maquina";
            // 
            // NumSpeed
            // 
            NumSpeed.Location = new Point(24, 22);
            NumSpeed.Minimum = new decimal(new int[] { 20, 0, 0, 0 });
            NumSpeed.Name = "NumSpeed";
            NumSpeed.Size = new Size(78, 23);
            NumSpeed.TabIndex = 0;
            NumSpeed.Value = new decimal(new int[] { 20, 0, 0, 0 });
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(NumNozzle);
            groupBox5.Location = new Point(12, 328);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(219, 70);
            groupBox5.TabIndex = 4;
            groupBox5.TabStop = false;
            groupBox5.Text = "Nozzle";
            // 
            // NumNozzle
            // 
            NumNozzle.Location = new Point(24, 27);
            NumNozzle.Maximum = new decimal(new int[] { 2, 0, 0, 0 });
            NumNozzle.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            NumNozzle.Name = "NumNozzle";
            NumNozzle.Size = new Size(78, 23);
            NumNozzle.TabIndex = 2;
            NumNozzle.Value = new decimal(new int[] { 2, 0, 0, 0 });
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(TxtPosicion);
            groupBox6.Location = new Point(12, 404);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(422, 70);
            groupBox6.TabIndex = 5;
            groupBox6.TabStop = false;
            groupBox6.Text = "Posicion";
            // 
            // TxtPosicion
            // 
            TxtPosicion.Location = new Point(24, 22);
            TxtPosicion.Name = "TxtPosicion";
            TxtPosicion.Size = new Size(109, 23);
            TxtPosicion.TabIndex = 1;
            // 
            // CmdOk
            // 
            CmdOk.Location = new Point(359, 532);
            CmdOk.Name = "CmdOk";
            CmdOk.Size = new Size(75, 23);
            CmdOk.TabIndex = 6;
            CmdOk.Text = "OK";
            CmdOk.UseVisualStyleBackColor = true;
            CmdOk.Click += CmdOk_Click;
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(NumAltura);
            groupBox7.Location = new Point(247, 328);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(187, 70);
            groupBox7.TabIndex = 5;
            groupBox7.TabStop = false;
            groupBox7.Text = "Altura";
            // 
            // NumAltura
            // 
            NumAltura.DecimalPlaces = 1;
            NumAltura.Location = new Point(24, 27);
            NumAltura.Maximum = new decimal(new int[] { 10, 0, 0, 0 });
            NumAltura.Name = "NumAltura";
            NumAltura.Size = new Size(78, 23);
            NumAltura.TabIndex = 2;
            // 
            // FrmComponente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(446, 567);
            Controls.Add(groupBox7);
            Controls.Add(CmdOk);
            Controls.Add(groupBox6);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "FrmComponente";
            Text = "Componente";
            Load += FrmComponente_Load;
            Shown += Show;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)NumSpeed).EndInit();
            groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)NumNozzle).EndInit();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)NumAltura).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox TxtDescripcion;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private GroupBox groupBox5;
        private GroupBox groupBox6;
        private ComboBox CmbPrecision;
        private CheckBox ChkPresion;
        private Label label1;
        private NumericUpDown NumSpeed;
        private NumericUpDown NumNozzle;
        private TextBox TxtPosicion;
        private Button CmdOk;
        private GroupBox groupBox7;
        private NumericUpDown NumAltura;
    }
}