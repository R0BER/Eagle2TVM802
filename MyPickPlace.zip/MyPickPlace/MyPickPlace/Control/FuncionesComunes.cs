﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPickPlace.Control
{
    public  class FuncionesComunes
    {
        public static CultureInfo IdiomaCalculos = new CultureInfo("en-US");

        public static string DecimalToString(decimal val)
        {
            return val.ToString("0.00", FuncionesComunes.IdiomaCalculos);
        }



    }
}
