﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Cryptography.Pkcs;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace MyPickPlace.Control.Componentes
{
    public  static class PcbComponentes
    {
      

        public static string RutaFile { get; set; } = "";

        public static  List<PlaceComponente > PcbParts= new List<PlaceComponente>();
        const string CabFile = @"""Designator"",""NozzleNum"",""StackNum"",""Mid X"",""Mid Y"",""Rotation"",""Height"",""Speed"",""Vision"",""Pressure"",""Explanation""";
        public  static string  Guardar()
        {
            if (RutaFile.Length < 5) return "Nombre archivo invalido";
            try
            {
                using (var writer = new StreamWriter(RutaFile))
                {
                    using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                    {
                     
                        csv.WriteRecords(PcbParts );
                    }

                }
                return "";
            }

           catch(Exception ex)
            {
                return ex.Message;
            }

        }
        public static string Abrir()
        {
            if (RutaFile.Length < 5) return "Nombre archivo invalido";
            try
            {
                using (var reader = new StreamReader(RutaFile))
                {
                        using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                        {
                            PcbParts = csv.GetRecords<PlaceComponente>().ToList();
                            

                        }
                }
                              
                return "";
            }

            catch (Exception ex)
            {
                return ex.Message;
            }


        }
        public static  string CargarArchivoMaquina()
        {
            if (RutaFile.Length < 5) return "Nombre archivo invalido";
            try
            {
                using (StreamReader re = new StreamReader(RutaFile))
                {
                    if (re.ReadLine() != CabFile) return "Archivo incorrecto";
                   
                    re.ReadLine();
                    string line = re.ReadLine().Replace(@"""", ""); ;
                    while (re.EndOfStream==false ){
                        

                        if (line != null)
                        {
                            ImporatdorDatos i = new ImporatdorDatos(line);
                            if (i.ImportadoCorrecto)
                            {
                                if (!ComponentesControl.Componentes.Keys.Contains(i.componente.StackNum)) ComponentesControl.Componentes.Add(i.componente.StackNum, i.componente);
                                PcbParts.Add(i.placeComponente);

                            }

                        }
                        line = re.ReadLine().Replace(@"""", "");
                    }
                }
              

                return "";
            }

            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public static string GenerarArchivoMaquina() {

            if (RutaFile.Length < 5) return "Nombre archivo invalido";
            try
            {
                using (StreamWriter wr = new StreamWriter(RutaFile))
                {
                    wr.WriteLine(CabFile );
                    wr.WriteLine("\"\"");
                    foreach (var part in PcbParts)
                    {
                        Componente CompSelect;
                        if (ComponentesControl.Componentes.ContainsKey(part.StackNum)) { 
                            CompSelect = ComponentesControl.Componentes[part.StackNum];

                            string l = "\"" + part.Nombre + "\",\"" + CompSelect.NozzleNum.ToString() + "\",\"" + part.StackNum + "\",\"" + part.PosX.ToString("0.00", FuncionesComunes.IdiomaCalculos) + "\",\""
                            + part.PosY.ToString("0.00", FuncionesComunes.IdiomaCalculos) + "\",\"" + part.Rotation.ToString("0.00", FuncionesComunes.IdiomaCalculos) + "\",\"" + CompSelect.Height.ToString("0.00", FuncionesComunes.IdiomaCalculos) + "\",\"" + CompSelect.Speed.ToString()
                            + "\",\"" + CompSelect.Vision.ToString() + "\",\"" + CompSelect.Pressure.ToString() + "\",\"" + CompSelect.Explanation.ToString() + "\"";
                            wr.WriteLine(l);
                        }
                    }    
                }
                return "";
            }

            catch (Exception ex)
            {
                return ex.Message;
            }



        }
    }

    public class ImporatdorDatos
    {

        public ImporatdorDatos(string line)
        {
            List<string> valores = new List<string>();
            int p = 0;

            while (p >= 0)
            {
                int p1 = line.IndexOf(",", p);
                if (p1 >= 0)
                {
                    valores.Add(line.Substring(p, p1 - p));
                    p = p1 + 1;
                }
                else
                {

                    string s = line.Substring(p, line.Length - p);
                    if (s != null && s.Length > 0) valores.Add(s);
                    p = -1;
                }


            }
            if (valores.Count == 11) {
                double d = 0;

                //Generamos componente
                try
                {
                    placeComponente.Nombre = valores[0];
                    placeComponente .PosX = Convert .ToDecimal(valores[3], FuncionesComunes.IdiomaCalculos );
                    placeComponente.PosY = Convert.ToDecimal(valores[4], FuncionesComunes.IdiomaCalculos);
                    placeComponente.Rotation = Convert.ToDecimal(valores[5], FuncionesComunes.IdiomaCalculos);
                    placeComponente.StackNum = valores[2];
                }
                catch 
                {
                    return;
                }

                //Generamos posicionamiento
                try
                {
                    componente .Explanation= valores[10];
                    componente.Pressure = Convert.ToBoolean ( valores[9]);
                    componente.Speed = Convert.ToInt32(valores[7]);
                    componente.NozzleNum = Convert.ToInt32(valores[1]);
                    componente.Height = Convert.ToDecimal(valores[6], FuncionesComunes.IdiomaCalculos);
                    componente.StackNum = valores[2];

                    if (valores[8]== "None" || valores[8] == "Quick" || valores[8] == "Accurate") componente .Vision = valores[8];
                    else return;

         
                }
                catch

                {
                    ImportadoCorrecto= false;

                }
                ImportadoCorrecto = true;
            }

    
            
            //public string Vision { get; set; } = "None";
          



       

            




        }

        public bool ImportadoCorrecto { get; set; }=false;
        public Componente componente { get; set; }= new Componente();
        public PlaceComponente placeComponente { get; set; } = new PlaceComponente();  
    


    }
}
