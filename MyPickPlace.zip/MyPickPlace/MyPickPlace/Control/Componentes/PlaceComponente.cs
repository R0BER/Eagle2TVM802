﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPickPlace.Control.Componentes
{
    public  class PlaceComponente
    {
        public string Nombre { get; set; }  

        public decimal  PosX { get; set; } = 0;
        public decimal PosY { get; set; } = 0;

        public decimal Rotation { get; set; }

        public string StackNum { get; set; } = "";
    }
}
