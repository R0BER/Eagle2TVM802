﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPickPlace.Control.Componentes
{
    public static class ComponentesControl
    {
        public static string RutaFile { get{
                return  Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Componentes.csv");
            }
        
        }



        public static  Dictionary<string, Componente> Componentes = new Dictionary<string, Componente>();


        public  static string Cargar()
        {
           return   Cargar(RutaFile);

        }
        public static void AddComponente(Componente co)
        {
            var l = Componentes .Values.ToList();
            l.Add(co);
            var or= l.OrderBy (e=>e.StackNum ).ToList();
            Dictionary<string, Componente> newcomp = new Dictionary<string, Componente>();

            or.ForEach(e => newcomp.Add(e.StackNum, e));
            Componentes = newcomp;

        }

        public static  string   Cargar(string ruta)
        {
            if (File.Exists (ruta))
            {
                
                if (ruta.ToUpper().EndsWith(".CSV") == false) return "El archivo no es csv"; 
                try
                { 
                    using (var reader = new StreamReader(ruta))
                    
                    {
                        using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                        {
                            Componentes.Clear();
                            var records = csv.GetRecords<Componente>().ToList();
                          
                            if (records != null ) {
                                
                                foreach (var c in records)
                                {
                                    Componentes.Add(c.StackNum, c);
                                }
                            }
                        }
                    }
                    return "Ok";

                }
                catch(Exception ex)
                {
                    return ex.Message;
                }
              
              
            }
            return "Archivo no existe";
        }
        public static void Guardar()
        {
            Guardar(RutaFile);

        }
        public static  void  Guardar (string ruta)
        {
            List<Componente> c = new List<Componente>();
            foreach ( var co in Componentes) {
                c.Add(co.Value);
            }


            using (var writer = new StreamWriter(ruta))
            {
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(c);
                }

            }
         

        }
    }
}
