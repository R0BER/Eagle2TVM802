﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPickPlace.Control.Componentes
{
    public  class Componente
    {
        public string Explanation { get; set; } = "";
        public bool Pressure { get; set; } = true;
        public string Vision { get; set; } = "None";
        public int Speed { get; set; } = 100;

        public int NozzleNum { get; set; } = 1;

        public string StackNum { get; set; } = "";

        public decimal Height { get; set; }   



    }

}
