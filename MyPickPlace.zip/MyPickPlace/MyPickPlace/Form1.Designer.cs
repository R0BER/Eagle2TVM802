﻿namespace MyPickPlace
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            toolStrip1 = new ToolStrip();
            CmdSave = new ToolStripButton();
            CmdGuadarComo = new ToolStripButton();
            CmdAbrir = new ToolStripButton();
            toolStripSeparator1 = new ToolStripSeparator();
            CmgPcbFile = new ToolStripButton();
            CmdImportar = new ToolStripButton();
            CmdEagle = new ToolStripButton();
            CmdDelete = new ToolStripButton();
            toolStripSeparator2 = new ToolStripSeparator();
            CmdComponentes = new ToolStripButton();
            toolStripSeparator3 = new ToolStripSeparator();
            CmdSelectAll = new ToolStripButton();
            CmdDeselect = new ToolStripButton();
            CmdSelectDelete = new ToolStripButton();
            CmdEditSelected = new ToolStripButton();
            toolStripSeparator4 = new ToolStripSeparator();
            Ayuda = new ToolStripButton();
            PanComponentes = new Panel();
            LblAltura = new Label();
            LblAngle = new Label();
            LblPosY = new Label();
            LblPosX = new Label();
            LblStack = new Label();
            LblNozzle = new Label();
            LblSpeed = new Label();
            LblVision = new Label();
            LblPresion = new Label();
            Descripcion = new Label();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new Size(40, 40);
            toolStrip1.Items.AddRange(new ToolStripItem[] { CmdSave, CmdGuadarComo, CmdAbrir, toolStripSeparator1, CmgPcbFile, CmdImportar, CmdEagle, CmdDelete, toolStripSeparator2, CmdComponentes, toolStripSeparator3, CmdSelectAll, CmdDeselect, CmdSelectDelete, CmdEditSelected, toolStripSeparator4, Ayuda });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(1231, 47);
            toolStrip1.TabIndex = 1;
            toolStrip1.Text = "toolStrip1";
            // 
            // CmdSave
            // 
            CmdSave.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdSave.Image = Properties.Resources.Save;
            CmdSave.ImageTransparentColor = Color.Magenta;
            CmdSave.Name = "CmdSave";
            CmdSave.Size = new Size(44, 44);
            CmdSave.Text = "Guardar";
            CmdSave.Click += CmdSave_Click;
            // 
            // CmdGuadarComo
            // 
            CmdGuadarComo.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdGuadarComo.Image = Properties.Resources.saveas;
            CmdGuadarComo.ImageTransparentColor = Color.Magenta;
            CmdGuadarComo.Name = "CmdGuadarComo";
            CmdGuadarComo.Size = new Size(44, 44);
            CmdGuadarComo.Text = "Guardar como";
            CmdGuadarComo.Click += CmdGuadarComo_Click;
            // 
            // CmdAbrir
            // 
            CmdAbrir.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdAbrir.Image = Properties.Resources.Open;
            CmdAbrir.ImageTransparentColor = Color.Magenta;
            CmdAbrir.Name = "CmdAbrir";
            CmdAbrir.Size = new Size(44, 44);
            CmdAbrir.Text = "Abrir";
            CmdAbrir.Click += CmdAbrir_Click;
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(6, 47);
            // 
            // CmgPcbFile
            // 
            CmgPcbFile.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmgPcbFile.Image = Properties.Resources.exportpcbfile;
            CmgPcbFile.ImageTransparentColor = Color.Magenta;
            CmgPcbFile.Name = "CmgPcbFile";
            CmgPcbFile.Size = new Size(44, 44);
            CmgPcbFile.Text = "Generar archivo pcb";
            CmgPcbFile.Click += CmgPcbFile_Click;
            // 
            // CmdImportar
            // 
            CmdImportar.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdImportar.Image = Properties.Resources.pcbfile2;
            CmdImportar.ImageTransparentColor = Color.Magenta;
            CmdImportar.Name = "CmdImportar";
            CmdImportar.Size = new Size(44, 44);
            CmdImportar.Text = "Importar archivo pcb";
            CmdImportar.Click += CmdImportar_Click;
            // 
            // CmdEagle
            // 
            CmdEagle.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdEagle.Image = Properties.Resources.eagle;
            CmdEagle.ImageTransparentColor = Color.Magenta;
            CmdEagle.Name = "CmdEagle";
            CmdEagle.Size = new Size(44, 44);
            CmdEagle.Text = "Cargar archivo eagle";
            CmdEagle.Click += CmdEagle_Click;
            // 
            // CmdDelete
            // 
            CmdDelete.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdDelete.Image = Properties.Resources.Borrar;
            CmdDelete.ImageTransparentColor = Color.Magenta;
            CmdDelete.Name = "CmdDelete";
            CmdDelete.Size = new Size(44, 44);
            CmdDelete.Text = "Borrar Todo";
            CmdDelete.Click += CmdDelete_Click;
            // 
            // toolStripSeparator2
            // 
            toolStripSeparator2.Name = "toolStripSeparator2";
            toolStripSeparator2.Size = new Size(6, 47);
            // 
            // CmdComponentes
            // 
            CmdComponentes.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdComponentes.Image = Properties.Resources.resitor;
            CmdComponentes.ImageTransparentColor = Color.Magenta;
            CmdComponentes.Name = "CmdComponentes";
            CmdComponentes.Size = new Size(44, 44);
            CmdComponentes.Text = "Componentes";
            CmdComponentes.Click += CmdComponentes_Click;
            // 
            // toolStripSeparator3
            // 
            toolStripSeparator3.Name = "toolStripSeparator3";
            toolStripSeparator3.Size = new Size(6, 47);
            // 
            // CmdSelectAll
            // 
            CmdSelectAll.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdSelectAll.Image = Properties.Resources.SelectAll;
            CmdSelectAll.ImageTransparentColor = Color.Magenta;
            CmdSelectAll.Name = "CmdSelectAll";
            CmdSelectAll.Size = new Size(44, 44);
            CmdSelectAll.Text = "Seleccionar Todo";
            CmdSelectAll.Click += CmdSelectAll_Click;
            // 
            // CmdDeselect
            // 
            CmdDeselect.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdDeselect.Image = Properties.Resources.SelectNone;
            CmdDeselect.ImageTransparentColor = Color.Magenta;
            CmdDeselect.Name = "CmdDeselect";
            CmdDeselect.Size = new Size(44, 44);
            CmdDeselect.Text = "Deseleccionar Todo";
            CmdDeselect.Click += CmdDeselect_Click;
            // 
            // CmdSelectDelete
            // 
            CmdSelectDelete.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdSelectDelete.Image = Properties.Resources.SelectDelete;
            CmdSelectDelete.ImageTransparentColor = Color.Magenta;
            CmdSelectDelete.Name = "CmdSelectDelete";
            CmdSelectDelete.Size = new Size(44, 44);
            CmdSelectDelete.Text = "Borrar Seleccionados";
            CmdSelectDelete.Click += CmdSelectDelete_Click;
            // 
            // CmdEditSelected
            // 
            CmdEditSelected.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdEditSelected.Image = Properties.Resources.SelectEdit;
            CmdEditSelected.ImageTransparentColor = Color.Magenta;
            CmdEditSelected.Name = "CmdEditSelected";
            CmdEditSelected.Size = new Size(44, 44);
            CmdEditSelected.Text = "Editar Componentes seleccionado";
            CmdEditSelected.Click += CmdEditSelected_Click;
            // 
            // toolStripSeparator4
            // 
            toolStripSeparator4.Name = "toolStripSeparator4";
            toolStripSeparator4.Size = new Size(6, 47);
            // 
            // Ayuda
            // 
            Ayuda.DisplayStyle = ToolStripItemDisplayStyle.Image;
            Ayuda.Image = (Image)resources.GetObject("Ayuda.Image");
            Ayuda.ImageTransparentColor = Color.Magenta;
            Ayuda.Name = "Ayuda";
            Ayuda.Size = new Size(44, 44);
            Ayuda.Text = "toolStripButton1";
            Ayuda.Click += Ayuda_Click;
            // 
            // PanComponentes
            // 
            PanComponentes.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PanComponentes.AutoScroll = true;
            PanComponentes.BackColor = SystemColors.Window;
            PanComponentes.Location = new Point(0, 74);
            PanComponentes.Name = "PanComponentes";
            PanComponentes.Size = new Size(1231, 438);
            PanComponentes.TabIndex = 2;
            // 
            // LblAltura
            // 
            LblAltura.AutoSize = true;
            LblAltura.Location = new Point(614, 54);
            LblAltura.Name = "LblAltura";
            LblAltura.Size = new Size(39, 15);
            LblAltura.TabIndex = 29;
            LblAltura.Text = "Altura";
            // 
            // LblAngle
            // 
            LblAngle.AutoSize = true;
            LblAngle.Location = new Point(561, 54);
            LblAngle.Name = "LblAngle";
            LblAngle.Size = new Size(38, 15);
            LblAngle.TabIndex = 28;
            LblAngle.Text = "Angle";
            // 
            // LblPosY
            // 
            LblPosY.AutoSize = true;
            LblPosY.Location = new Point(508, 54);
            LblPosY.Name = "LblPosY";
            LblPosY.Size = new Size(33, 15);
            LblPosY.TabIndex = 27;
            LblPosY.Text = "PosY";
            // 
            // LblPosX
            // 
            LblPosX.AutoSize = true;
            LblPosX.Location = new Point(449, 54);
            LblPosX.Name = "LblPosX";
            LblPosX.Size = new Size(33, 15);
            LblPosX.TabIndex = 26;
            LblPosX.Text = "PosX";
            // 
            // LblStack
            // 
            LblStack.AutoSize = true;
            LblStack.Location = new Point(964, 51);
            LblStack.Name = "LblStack";
            LblStack.Size = new Size(52, 15);
            LblStack.TabIndex = 25;
            LblStack.Text = "Posicion";
            // 
            // LblNozzle
            // 
            LblNozzle.AutoSize = true;
            LblNozzle.Location = new Point(899, 54);
            LblNozzle.Name = "LblNozzle";
            LblNozzle.Size = new Size(42, 15);
            LblNozzle.TabIndex = 24;
            LblNozzle.Text = "Nozzle";
            // 
            // LblSpeed
            // 
            LblSpeed.AutoSize = true;
            LblSpeed.Location = new Point(835, 54);
            LblSpeed.Name = "LblSpeed";
            LblSpeed.Size = new Size(39, 15);
            LblSpeed.TabIndex = 23;
            LblSpeed.Text = "Speed";
            // 
            // LblVision
            // 
            LblVision.AutoSize = true;
            LblVision.Location = new Point(755, 54);
            LblVision.Name = "LblVision";
            LblVision.Size = new Size(39, 15);
            LblVision.TabIndex = 22;
            LblVision.Text = "Vision";
            // 
            // LblPresion
            // 
            LblPresion.AutoSize = true;
            LblPresion.Location = new Point(696, 54);
            LblPresion.Name = "LblPresion";
            LblPresion.Size = new Size(46, 15);
            LblPresion.TabIndex = 21;
            LblPresion.Text = "Presion";
            // 
            // Descripcion
            // 
            Descripcion.AutoSize = true;
            Descripcion.Location = new Point(25, 56);
            Descripcion.Name = "Descripcion";
            Descripcion.Size = new Size(69, 15);
            Descripcion.TabIndex = 20;
            Descripcion.Text = "Explanation";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1231, 513);
            Controls.Add(LblAltura);
            Controls.Add(LblAngle);
            Controls.Add(LblPosY);
            Controls.Add(LblPosX);
            Controls.Add(LblStack);
            Controls.Add(LblNozzle);
            Controls.Add(LblSpeed);
            Controls.Add(LblVision);
            Controls.Add(LblPresion);
            Controls.Add(Descripcion);
            Controls.Add(PanComponentes);
            Controls.Add(toolStrip1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ToolStrip toolStrip1;
        private ToolStripButton CmdSave;
        private ToolStripButton CmdAbrir;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripButton CmgPcbFile;
        private ToolStripButton CmdImportar;
        private ToolStripButton CmdEagle;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripButton Ayuda;
        private ToolStripButton CmdComponentes;
        private ToolStripSeparator toolStripSeparator3;
        private Panel PanComponentes;
        private ToolStripButton CmdDelete;
        private Label LblAltura;
        private Label LblAngle;
        private Label LblPosY;
        private Label LblPosX;
        private Label LblStack;
        private Label LblNozzle;
        private Label LblSpeed;
        private Label LblVision;
        private Label LblPresion;
        private Label Descripcion;
        private ToolStripButton CmdGuadarComo;
        private ToolStripButton toolStripButton1;
        private ToolStripButton toolStripButton2;
        private ToolStripButton toolStripButton3;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripButton CmdDeselect;
        private ToolStripButton CmdSelectDelete;
        private ToolStripButton CmdEditSelected;
        private ToolStripButton CmdSelectAll;
    }
}