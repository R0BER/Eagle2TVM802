﻿using MyPickPlace.Control.Componentes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPickPlace
{
    public partial class FrmSeleccionarOrigen : Form
    {
        public FrmSeleccionarOrigen()
        {
            InitializeComponent();
        }
        public string Seleccionado { get; set; }

        private void FrmSeleccionarOrigen_Load(object sender, EventArgs e)
        {
            foreach (var c in ComponentesControl.Componentes)
            {
                ComboboxItem item = new ComboboxItem();
                item.Text = c.Key.PadRight(8, ' ') + " " + c.Value.Explanation;
                item.Value = c.Key;


                CmbPosiciones.Items.Add(item);
            }
        }

        private void CmdAceptar_Click(object sender, EventArgs e)
        {
            if (CmbPosiciones.SelectedItem != null)
            {
                ComboboxItem Val = (ComboboxItem)CmbPosiciones.SelectedItem;
                Seleccionado = Val.Value.ToString() ;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }
    }
}
