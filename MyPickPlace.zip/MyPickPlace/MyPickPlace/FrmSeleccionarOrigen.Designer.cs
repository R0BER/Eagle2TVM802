﻿namespace MyPickPlace
{
    partial class FrmSeleccionarOrigen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CmdAceptar = new Button();
            groupBox3 = new GroupBox();
            CmbPosiciones = new ComboBox();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // CmdAceptar
            // 
            CmdAceptar.Location = new Point(343, 135);
            CmdAceptar.Name = "CmdAceptar";
            CmdAceptar.Size = new Size(75, 23);
            CmdAceptar.TabIndex = 15;
            CmdAceptar.Text = "Ok";
            CmdAceptar.UseVisualStyleBackColor = true;
            CmdAceptar.Click += CmdAceptar_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(CmbPosiciones);
            groupBox3.Location = new Point(2, 22);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(422, 70);
            groupBox3.TabIndex = 14;
            groupBox3.TabStop = false;
            groupBox3.Text = "Situacion Componente";
            // 
            // CmbPosiciones
            // 
            CmbPosiciones.FormattingEnabled = true;
            CmbPosiciones.Location = new Point(25, 22);
            CmbPosiciones.Name = "CmbPosiciones";
            CmbPosiciones.Size = new Size(375, 23);
            CmbPosiciones.TabIndex = 0;
            // 
            // FrmSeleccionarOrigen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(441, 169);
            Controls.Add(CmdAceptar);
            Controls.Add(groupBox3);
            Name = "FrmSeleccionarOrigen";
            Text = "Seleccionar Origen";
            Load += FrmSeleccionarOrigen_Load;
            groupBox3.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button CmdAceptar;
        private GroupBox groupBox3;
        private ComboBox CmbPosiciones;
    }
}