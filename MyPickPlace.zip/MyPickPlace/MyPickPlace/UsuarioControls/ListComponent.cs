﻿using MyPickPlace.Control.Componentes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPickPlace.UsuarioControls
{



    public partial class ListComponent : UserControl
    {
        public Componente componente { get; set; }

        public delegate void Pulsado(Componente co);
        public event Pulsado Editar;
        public event Pulsado Borrar;
        public ListComponent()
        {
            InitializeComponent();
        }

        private void ListComponent_Load(object sender, EventArgs e)
        {

        }
        public void Iniciar(Componente com)
        {
            componente = com;
            LblExplanation.Text = componente.Explanation;
            LblPresion.Text = componente.Pressure.ToString();
            LblVision.Text = componente.Vision;
            LblSpeed.Text = componente.Speed.ToString();
            LblNozzle.Text = componente.NozzleNum.ToString();
            LblStack.Text = componente.StackNum.ToString();
            LblAltura.Text = componente.Height.ToString();

        }

        private void CmdEdit_Click(object sender, EventArgs e)
        {
            Editar?.Invoke(componente);
        }

        private void CmdDelete_Click(object sender, EventArgs e)
        {
            Borrar?.Invoke(componente);
        }
    }
}
