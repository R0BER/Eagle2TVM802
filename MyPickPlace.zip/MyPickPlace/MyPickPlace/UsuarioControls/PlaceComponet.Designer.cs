﻿namespace MyPickPlace.UsuarioControls
{
    partial class PlaceComponet
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            LblStack = new Label();
            LblNozzle = new Label();
            LblSpeed = new Label();
            LblVision = new Label();
            LblPresion = new Label();
            CmdEdit = new Button();
            CmdDelete = new Button();
            LblExplanation = new Label();
            LblAngle = new Label();
            LblPosY = new Label();
            LblPosX = new Label();
            LblAltura = new Label();
            CmdSelect = new Button();
            SuspendLayout();
            // 
            // LblStack
            // 
            LblStack.AutoSize = true;
            LblStack.Location = new Point(953, 6);
            LblStack.Name = "LblStack";
            LblStack.Size = new Size(19, 15);
            LblStack.TabIndex = 15;
            LblStack.Text = "L1";
            // 
            // LblNozzle
            // 
            LblNozzle.AutoSize = true;
            LblNozzle.Location = new Point(888, 9);
            LblNozzle.Name = "LblNozzle";
            LblNozzle.Size = new Size(13, 15);
            LblNozzle.TabIndex = 14;
            LblNozzle.Text = "1";
            // 
            // LblSpeed
            // 
            LblSpeed.AutoSize = true;
            LblSpeed.Location = new Point(824, 9);
            LblSpeed.Name = "LblSpeed";
            LblSpeed.Size = new Size(25, 15);
            LblSpeed.TabIndex = 13;
            LblSpeed.Text = "100";
            // 
            // LblVision
            // 
            LblVision.AutoSize = true;
            LblVision.Location = new Point(744, 9);
            LblVision.Name = "LblVision";
            LblVision.Size = new Size(39, 15);
            LblVision.TabIndex = 12;
            LblVision.Text = "Vision";
            // 
            // LblPresion
            // 
            LblPresion.AutoSize = true;
            LblPresion.Location = new Point(685, 9);
            LblPresion.Name = "LblPresion";
            LblPresion.Size = new Size(33, 15);
            LblPresion.TabIndex = 11;
            LblPresion.Text = "False";
            // 
            // CmdEdit
            // 
            CmdEdit.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CmdEdit.BackgroundImage = Properties.Resources.edit;
            CmdEdit.BackgroundImageLayout = ImageLayout.Stretch;
            CmdEdit.Location = new Point(1106, 0);
            CmdEdit.Name = "CmdEdit";
            CmdEdit.Size = new Size(27, 27);
            CmdEdit.TabIndex = 10;
            CmdEdit.UseVisualStyleBackColor = true;
            CmdEdit.Click += CmdEdit_Click_1;
            // 
            // CmdDelete
            // 
            CmdDelete.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CmdDelete.BackgroundImage = Properties.Resources.delete;
            CmdDelete.BackgroundImageLayout = ImageLayout.Stretch;
            CmdDelete.Location = new Point(1139, -1);
            CmdDelete.Name = "CmdDelete";
            CmdDelete.Size = new Size(27, 27);
            CmdDelete.TabIndex = 9;
            CmdDelete.UseVisualStyleBackColor = true;
            CmdDelete.Click += CmdDelete_Click_1;
            // 
            // LblExplanation
            // 
            LblExplanation.AutoSize = true;
            LblExplanation.Location = new Point(14, 11);
            LblExplanation.Name = "LblExplanation";
            LblExplanation.Size = new Size(69, 15);
            LblExplanation.TabIndex = 8;
            LblExplanation.Text = "Explanation";
            // 
            // LblAngle
            // 
            LblAngle.AutoSize = true;
            LblAngle.Location = new Point(550, 9);
            LblAngle.Name = "LblAngle";
            LblAngle.Size = new Size(13, 15);
            LblAngle.TabIndex = 18;
            LblAngle.Text = "0";
            // 
            // LblPosY
            // 
            LblPosY.AutoSize = true;
            LblPosY.Location = new Point(497, 9);
            LblPosY.Name = "LblPosY";
            LblPosY.Size = new Size(22, 15);
            LblPosY.TabIndex = 17;
            LblPosY.Text = "0.0";
            // 
            // LblPosX
            // 
            LblPosX.AutoSize = true;
            LblPosX.Location = new Point(438, 9);
            LblPosX.Name = "LblPosX";
            LblPosX.Size = new Size(22, 15);
            LblPosX.TabIndex = 16;
            LblPosX.Text = "0.0";
            // 
            // LblAltura
            // 
            LblAltura.AutoSize = true;
            LblAltura.Location = new Point(603, 9);
            LblAltura.Name = "LblAltura";
            LblAltura.Size = new Size(22, 15);
            LblAltura.TabIndex = 19;
            LblAltura.Text = "0.0";
            // 
            // CmdSelect
            // 
            CmdSelect.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CmdSelect.BackgroundImageLayout = ImageLayout.Stretch;
            CmdSelect.Location = new Point(1073, 0);
            CmdSelect.Name = "CmdSelect";
            CmdSelect.Size = new Size(27, 27);
            CmdSelect.TabIndex = 20;
            CmdSelect.UseVisualStyleBackColor = true;
            CmdSelect.Click += CmdSelect_Click;
            // 
            // PlaceComponet
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            Controls.Add(CmdSelect);
            Controls.Add(LblAltura);
            Controls.Add(LblAngle);
            Controls.Add(LblPosY);
            Controls.Add(LblPosX);
            Controls.Add(LblStack);
            Controls.Add(LblNozzle);
            Controls.Add(LblSpeed);
            Controls.Add(LblVision);
            Controls.Add(LblPresion);
            Controls.Add(CmdEdit);
            Controls.Add(CmdDelete);
            Controls.Add(LblExplanation);
            Name = "PlaceComponet";
            Size = new Size(1173, 30);
            Load += PlaceComponet_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LblStack;
        private Label LblNozzle;
        private Label LblSpeed;
        private Label LblVision;
        private Label LblPresion;
        private Button CmdEdit;
        private Button CmdDelete;
        private Label LblExplanation;
        private Label LblAngle;
        private Label LblPosY;
        private Label LblPosX;
        private Label LblAltura;
        private Button CmdSelect;
    }
}
