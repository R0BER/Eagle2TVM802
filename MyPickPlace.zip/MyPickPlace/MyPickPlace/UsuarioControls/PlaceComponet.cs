﻿using MyPickPlace.Control.Componentes;
using MyPickPlace.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPickPlace.UsuarioControls
{
    public partial class PlaceComponet : UserControl
    {
        public PlaceComponente componente { get; set; }

        public delegate void Pulsado(PlaceComponente co);
        public event Pulsado Editar;
        public event Pulsado Borrar;
        bool select= false;


        public PlaceComponet()
        {
            InitializeComponent();
        }
        public bool Seleccionado
        {
            get { return select; }
            set {
                select = value;
                if (select) CmdSelect.BackgroundImage = Resources.select;
                else CmdSelect.BackgroundImage = null;

            }
        }
        public void Iniciar(PlaceComponente com)
        {
            componente = com;
            LblExplanation.Text = componente.Nombre;
            LblPosX.Text = componente.PosX.ToString();
            LblPosY.Text = componente.PosY.ToString();
            LblAngle.Text = componente.Rotation.ToString();


            if (ComponentesControl.Componentes.ContainsKey(com.StackNum))
            {
                var comBase = ComponentesControl.Componentes[com.StackNum];

                LblPresion.Text = comBase.Pressure.ToString();
                LblVision.Text = comBase.Vision;
                LblSpeed.Text = comBase.Speed.ToString();
                LblNozzle.Text = comBase.NozzleNum.ToString();
                LblStack.Text = comBase.StackNum.ToString();
                LblAltura.Text = comBase.Height.ToString();
            }
            else
            {
                LblPresion.Text = "";
                LblVision.Text = "";
                LblSpeed.Text = "";
                LblNozzle.Text = "";
                LblStack.Text = "";
                LblAltura.Text = "";
            }

        }


        private void CmdEdit_Click_1(object sender, EventArgs e)
        {
            Editar?.Invoke(componente);
        }

        private void CmdDelete_Click_1(object sender, EventArgs e)
        {
            Borrar?.Invoke(componente);
        }

        private void PlaceComponet_Load(object sender, EventArgs e)
        {

        }

        private void CmdSelect_Click(object sender, EventArgs e)
        {
            Seleccionado = !Seleccionado;
           
        }
    }
}
