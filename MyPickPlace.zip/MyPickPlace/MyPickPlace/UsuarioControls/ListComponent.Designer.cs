﻿namespace MyPickPlace.UsuarioControls
{
    partial class ListComponent
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            CmdDelete = new Button();
            CmdEdit = new Button();
            LblStack = new Label();
            LblNozzle = new Label();
            LblSpeed = new Label();
            LblVision = new Label();
            LblExplanation = new Label();
            LblPresion = new Label();
            LblAltura = new Label();
            SuspendLayout();
            // 
            // CmdDelete
            // 
            CmdDelete.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CmdDelete.BackgroundImage = Properties.Resources.delete;
            CmdDelete.BackgroundImageLayout = ImageLayout.Stretch;
            CmdDelete.Location = new Point(896, 3);
            CmdDelete.Name = "CmdDelete";
            CmdDelete.Size = new Size(27, 27);
            CmdDelete.TabIndex = 1;
            CmdDelete.UseVisualStyleBackColor = true;
            CmdDelete.Click += CmdDelete_Click;
            // 
            // CmdEdit
            // 
            CmdEdit.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            CmdEdit.BackgroundImage = Properties.Resources.edit;
            CmdEdit.BackgroundImageLayout = ImageLayout.Stretch;
            CmdEdit.Location = new Point(863, 4);
            CmdEdit.Name = "CmdEdit";
            CmdEdit.Size = new Size(27, 27);
            CmdEdit.TabIndex = 2;
            CmdEdit.UseVisualStyleBackColor = true;
            CmdEdit.Click += CmdEdit_Click;
            // 
            // LblStack
            // 
            LblStack.AutoSize = true;
            LblStack.Location = new Point(766, 10);
            LblStack.Name = "LblStack";
            LblStack.Size = new Size(19, 15);
            LblStack.TabIndex = 7;
            LblStack.Text = "L1";
            // 
            // LblNozzle
            // 
            LblNozzle.AutoSize = true;
            LblNozzle.Location = new Point(710, 10);
            LblNozzle.Name = "LblNozzle";
            LblNozzle.Size = new Size(13, 15);
            LblNozzle.TabIndex = 6;
            LblNozzle.Text = "1";
            // 
            // LblSpeed
            // 
            LblSpeed.AutoSize = true;
            LblSpeed.Location = new Point(553, 10);
            LblSpeed.Name = "LblSpeed";
            LblSpeed.Size = new Size(25, 15);
            LblSpeed.TabIndex = 5;
            LblSpeed.Text = "100";
            // 
            // LblVision
            // 
            LblVision.AutoSize = true;
            LblVision.Location = new Point(473, 10);
            LblVision.Name = "LblVision";
            LblVision.Size = new Size(39, 15);
            LblVision.TabIndex = 4;
            LblVision.Text = "Vision";
            // 
            // LblExplanation
            // 
            LblExplanation.AutoSize = true;
            LblExplanation.Location = new Point(16, 10);
            LblExplanation.Name = "LblExplanation";
            LblExplanation.Size = new Size(69, 15);
            LblExplanation.TabIndex = 0;
            LblExplanation.Text = "Explanation";
            // 
            // LblPresion
            // 
            LblPresion.AutoSize = true;
            LblPresion.Location = new Point(414, 10);
            LblPresion.Name = "LblPresion";
            LblPresion.Size = new Size(33, 15);
            LblPresion.TabIndex = 3;
            LblPresion.Text = "False";
            // 
            // LblAltura
            // 
            LblAltura.AutoSize = true;
            LblAltura.Location = new Point(623, 9);
            LblAltura.Name = "LblAltura";
            LblAltura.Size = new Size(28, 15);
            LblAltura.TabIndex = 8;
            LblAltura.Text = "12.5";
            // 
            // ListComponent
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(LblAltura);
            Controls.Add(LblStack);
            Controls.Add(LblNozzle);
            Controls.Add(LblSpeed);
            Controls.Add(LblVision);
            Controls.Add(LblPresion);
            Controls.Add(CmdEdit);
            Controls.Add(CmdDelete);
            Controls.Add(LblExplanation);
            Name = "ListComponent";
            Size = new Size(929, 30);
            Load += ListComponent_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button CmdDelete;
        private Button CmdEdit;
        private Label LblStack;
        private Label LblNozzle;
        private Label LblSpeed;
        private Label LblVision;
        private Label LblExplanation;
        private Label LblPresion;
        private Label LblAltura;
    }
}
