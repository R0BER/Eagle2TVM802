using CsvHelper;
using MyPickPlace.Control;
using MyPickPlace.Control.Componentes;
using MyPickPlace.UsuarioControls;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Windows.Forms;

namespace MyPickPlace
{
    public partial class Form1 : Form
    {




        public Form1()
        {

            InitializeComponent();



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ComponentesControl.Cargar();
            //FrmComponentes f = new FrmComponentes();
            //f.ShowDialog();


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void CmdEagle_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                var resp = openFileDialog.ShowDialog(this);
                if (resp == DialogResult.OK)
                {
                    if (openFileDialog.FileName.ToUpper().EndsWith(".MNT"))
                    {

                        using (var reader = new StreamReader(openFileDialog.FileName))
                        {

                            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                            {
                                // Do any configuration to `CsvReader` before creating CsvDataReader.
                                using (var dr = new CsvDataReader(csv))
                                {
                                    var dt = new DataTable();


                                    dt.Load(dr);





                                    foreach (DataRow r in dt.Rows)
                                    {


                                        PlaceComponente componente = new PlaceComponente();

                                        componente.Nombre = r.ItemArray[0].ToString() + " " + r.ItemArray[1].ToString() + " (" + r.ItemArray[2].ToString() + ")";
                                        componente.PosX = Convert.ToDecimal(r.ItemArray[3], FuncionesComunes.IdiomaCalculos);
                                        componente.PosY = Convert.ToDecimal(r.ItemArray[4], FuncionesComunes.IdiomaCalculos);
                                        componente.Rotation = Convert.ToDecimal(r.ItemArray[5], FuncionesComunes.IdiomaCalculos);

                                        PcbComponentes.PcbParts.Add(componente);

                                    }
                                    PintarTodo();

                                }
                            }


                        }
                    }
                    else
                    {
                        MessageBox.Show("El archivo no es .MNT", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "No se pudo abrir", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PintarTodo()
        {
            PanComponentes.Controls.Clear();
            int p = 0;
            foreach (var c in PcbComponentes.PcbParts)
            {
                PintaControl(c, p);
                p++;
            }
        }
        private void PintaControl(PlaceComponente co, int position)
        {

            PlaceComponet com = new PlaceComponet();
            com.Iniciar(co);
            com.Top = position * 30;
            PanComponentes.Controls.Add(com);

            com.Editar += EditarComponente;
            com.Borrar += BorrarComponente;
        }
        private void EditarComponente(PlaceComponente co)
        {
            FrmPlaceComponente f = new FrmPlaceComponente();
            f.Iniciar(co);
            var r = f.ShowDialog();
            if (r == DialogResult.OK) PintarTodo();
        }
        private void BorrarComponente(PlaceComponente co)
        {
            var res = MessageBox.Show("Confirma borrado?", "Borrar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                PcbComponentes.PcbParts.Remove(co);
                PintarTodo();
            }

        }

        private void CmdComponentes_Click(object sender, EventArgs e)
        {
            FrmComponentes f = new FrmComponentes();
            f.ShowDialog();

        }

        private void CmdSave_Click(object sender, EventArgs e)
        {
            if (PcbComponentes.RutaFile.Length < 5)
            {
                GuardarComo();
            }
            else
            {
                var rs = PcbComponentes.Guardar();
                if (rs.Length > 0) MessageBox.Show(rs, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void GuardarComo()
        {
            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "csv files (*.csv)|*.csv";
            var r = f.ShowDialog();
            if (r == DialogResult.OK)
            {
                PcbComponentes.RutaFile = f.FileName;
                var rs = PcbComponentes.Guardar();
                if (rs.Length > 0) MessageBox.Show(rs, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void CmdAbrir_Click(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "csv files (*.csv)|*.csv";
            var r = f.ShowDialog();
            if (r == DialogResult.OK)
            {
                PcbComponentes.RutaFile = f.FileName;

                var rs = PcbComponentes.Abrir();
                if (rs.Length > 0) MessageBox.Show(rs, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else PintarTodo();
            }

        }

        private void CmdGuadarComo_Click(object sender, EventArgs e)
        {
            GuardarComo();
        }

        private void CmdDelete_Click(object sender, EventArgs e)
        {

            var rsp = MessageBox.Show("Confirma borrar listado componentes", "Borrado total", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (rsp == DialogResult.Yes)
            {
                PcbComponentes.PcbParts.Clear();
                PintarTodo();
            }

        }

        private void CmgPcbFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "csv files (*.csv)|*.csv";
            var r = f.ShowDialog();
            if (r == DialogResult.OK)
            {
                PcbComponentes.RutaFile = f.FileName;
                var rs = PcbComponentes.GenerarArchivoMaquina();
                if (rs.Length > 0) MessageBox.Show(rs, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void CmdImportar_Click(object sender, EventArgs e)
        {



            OpenFileDialog f = new OpenFileDialog();
            var r = f.ShowDialog(this);
            if (r == DialogResult.OK)
            {
                PcbComponentes.RutaFile = f.FileName;
                var rs = PcbComponentes.CargarArchivoMaquina();
                if (rs.Length > 0) MessageBox.Show(rs, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else PintarTodo();

            }

        }

        private void Ayuda_Click(object sender, EventArgs e)
        {
            FrmHelp f = new FrmHelp();
            f.ShowDialog();
        }
        private void CambiarSeleccionControles(bool val)
        {
            foreach (var co in PanComponentes.Controls)
            {
                var kk = co.GetType();
                if (co.GetType().Name == "PlaceComponet")
                {
                    MyPickPlace.UsuarioControls.PlaceComponet com = (MyPickPlace.UsuarioControls.PlaceComponet)co;
                    com.Seleccionado = val;


                }
            }
        }
        private List<MyPickPlace.UsuarioControls.PlaceComponet> GetSeleccionados()
        {
            List<MyPickPlace.UsuarioControls.PlaceComponet> result = new List<PlaceComponet>();
            foreach (var co in PanComponentes.Controls)
            {
                var kk = co.GetType();
                if (co.GetType().Name == "PlaceComponet")
                {
                    MyPickPlace.UsuarioControls.PlaceComponet com = (MyPickPlace.UsuarioControls.PlaceComponet)co;
                    if (com.Seleccionado) result.Add(com);

                }
            }
            return result;
        }

        private void CmdSelectAll_Click(object sender, EventArgs e)
        {
            CambiarSeleccionControles(true);
        }

        private void CmdDeselect_Click(object sender, EventArgs e)
        {
            CambiarSeleccionControles(false);
        }

        private void CmdSelectDelete_Click(object sender, EventArgs e)
        {
            var con = GetSeleccionados();
            if (con.Any())
            {
                var rsp = MessageBox.Show("Confirma Borrar seleccionados?", "Confirmar", MessageBoxButtons.YesNo);
                if (rsp == DialogResult.Yes)
                {
                    foreach (var co in con)
                    {
                        PcbComponentes.PcbParts.Remove(co.componente);

                    }
                }
                PintarTodo();
            }
        }

        private void CmdEditSelected_Click(object sender, EventArgs e)
        {
            var con = GetSeleccionados();
            if (con.Any())
            {
                FrmSeleccionarOrigen f = new FrmSeleccionarOrigen();
                var r = f.ShowDialog();
                if (r == DialogResult.OK)
                {
                    foreach (var co in con) co.componente.StackNum = f.Seleccionado;

                }



                PintarTodo();
            }
        }
    }
}
