﻿using MyPickPlace.Control.Componentes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPickPlace
{
    public partial class FrmComponente : Form
    {
        public Componente componente;


        public FrmComponente()
        {
            InitializeComponent();
        }

        private void FrmComponente_Load(object sender, EventArgs e)
        {

        }
        private void Show(object sender, EventArgs e)
        {
            if (componente == null)
            {
                CmbPrecision.SelectedIndex = 0;

            }
            else
            {
                TxtDescripcion.Text = componente.Explanation;
                TxtPosicion.Text = componente.StackNum;
                NumNozzle.Value = componente.NozzleNum;
                NumSpeed.Value = componente.Speed;
                ChkPresion.Checked = componente.Pressure;
                CmbPrecision.SelectedItem = componente.Vision;
                NumAltura.Value = componente.Height;


            }
        }
        private void CmdOk_Click(object sender, EventArgs e)
        {



            if (TxtDescripcion.Text.Length < 2)
            {
                MessageBox.Show("Descripción muy corta");
                return;

            }
            if (TxtPosicion.Text.Length < 2)
            {
                MessageBox.Show("Posicion Incorrecta");
                return;
            }

            TxtPosicion.Text = TxtPosicion.Text.ToUpper();

            if (componente == null)
            {
                if (ComponentesControl.Componentes.ContainsKey(TxtPosicion.Text))
                {

                    MessageBox.Show("Posicion asignada a otro componente");
                    return;

                }
                componente = new Componente();
            }
            componente.StackNum = TxtPosicion.Text;
            componente.Pressure = ChkPresion.Checked;
            if (CmbPrecision.SelectedItem!=null) componente.Vision = CmbPrecision.SelectedItem.ToString();
            componente.Explanation = TxtDescripcion.Text;
            componente.NozzleNum = (int)NumNozzle.Value;
            componente.Speed = (int)NumSpeed.Value;
            componente.Height = NumAltura.Value;

            this.DialogResult = DialogResult.OK;
            this.Close();

        }
    }
}
