﻿using MyPickPlace.Control.Componentes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPickPlace
{
    public partial class FrmPlaceComponente : Form
    {
        public PlaceComponente componente;

        public FrmPlaceComponente()
        {
            InitializeComponent();
        }
        public void Iniciar(PlaceComponente co)
        {
            componente = co;
            TxtDescripcion.Text = co.Nombre;
            NumPosX.Value = co.PosX;
            NumPosY.Value = co.PosY;
            NumRotacion.Value = co.Rotation;

            if (co.StackNum.Length > 0)
            {
                if (ComponentesControl.Componentes.ContainsKey(co.StackNum))
                {
                    var c = ComponentesControl.Componentes[co.StackNum];
                    CmbPosiciones.Text = c.Explanation + " (" + c.StackNum + ")";
                }
            }

        }

        private void FrmPlaceComponente_Load(object sender, EventArgs e)
        {
            foreach (var c in ComponentesControl.Componentes)
            {
                ComboboxItem item = new ComboboxItem();
                item.Text = c.Key.PadRight (8,' ') + " "+  c.Value.Explanation ;
                item.Value = c.Key;


                CmbPosiciones.Items.Add(item);
            }


        }

        private void CmdAceptar_Click(object sender, EventArgs e)
        {
            if (TxtDescripcion .Text .Length <3 )
            {
                MessageBox.Show("Incluir nombre");
                return;
            }



            if (componente == null) componente = new PlaceComponente();

            componente.Rotation = NumRotacion.Value;
            componente .PosX= NumPosX.Value;
            componente.PosY = NumPosY.Value;

            componente.Nombre = TxtDescripcion.Text;

            if (CmbPosiciones .SelectedItem!=null)
            {
                ComboboxItem Val = (ComboboxItem)CmbPosiciones.SelectedItem;
                componente.StackNum = Val.Value .ToString();
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
