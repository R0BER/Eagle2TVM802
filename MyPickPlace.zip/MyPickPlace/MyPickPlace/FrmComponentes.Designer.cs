﻿namespace MyPickPlace
{
    partial class FrmComponentes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmComponentes));
            PanComponentes = new Panel();
            LblExplanation = new Label();
            LblPresion = new Label();
            LblVision = new Label();
            LblSpeed = new Label();
            LblPos = new Label();
            toolStrip1 = new ToolStrip();
            CmdSave = new ToolStripButton();
            CmdOpen = new ToolStripButton();
            CmdExport = new ToolStripButton();
            toolStripSeparator1 = new ToolStripSeparator();
            Añadir = new ToolStripButton();
            CmdBorrar = new ToolStripButton();
            label1 = new Label();
            label2 = new Label();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // PanComponentes
            // 
            PanComponentes.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            PanComponentes.AutoScroll = true;
            PanComponentes.Location = new Point(1, 63);
            PanComponentes.Name = "PanComponentes";
            PanComponentes.Size = new Size(1004, 384);
            PanComponentes.TabIndex = 14;
            // 
            // LblExplanation
            // 
            LblExplanation.AutoSize = true;
            LblExplanation.Location = new Point(1, 45);
            LblExplanation.Name = "LblExplanation";
            LblExplanation.Size = new Size(69, 15);
            LblExplanation.TabIndex = 8;
            LblExplanation.Text = "Descripcion";
            // 
            // LblPresion
            // 
            LblPresion.AutoSize = true;
            LblPresion.Location = new Point(399, 45);
            LblPresion.Name = "LblPresion";
            LblPresion.Size = new Size(55, 15);
            LblPresion.TabIndex = 9;
            LblPresion.Text = "Precisión";
            // 
            // LblVision
            // 
            LblVision.AutoSize = true;
            LblVision.Location = new Point(473, 45);
            LblVision.Name = "LblVision";
            LblVision.Size = new Size(39, 15);
            LblVision.TabIndex = 10;
            LblVision.Text = "Vision";
            // 
            // LblSpeed
            // 
            LblSpeed.AutoSize = true;
            LblSpeed.Location = new Point(537, 45);
            LblSpeed.Name = "LblSpeed";
            LblSpeed.Size = new Size(39, 15);
            LblSpeed.TabIndex = 11;
            LblSpeed.Text = "Speed";
            LblSpeed.Click += LblSpeed_Click;
            // 
            // LblPos
            // 
            LblPos.AutoSize = true;
            LblPos.Location = new Point(689, 45);
            LblPos.Name = "LblPos";
            LblPos.Size = new Size(33, 15);
            LblPos.TabIndex = 12;
            LblPos.Text = "Boca";
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new Size(25, 25);
            toolStrip1.Items.AddRange(new ToolStripItem[] { CmdSave, CmdOpen, CmdExport, toolStripSeparator1, Añadir, CmdBorrar });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(1005, 32);
            toolStrip1.TabIndex = 16;
            toolStrip1.Text = "toolStrip1";
            // 
            // CmdSave
            // 
            CmdSave.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdSave.Image = Properties.Resources.Save;
            CmdSave.ImageTransparentColor = Color.Magenta;
            CmdSave.Name = "CmdSave";
            CmdSave.Size = new Size(29, 29);
            CmdSave.Text = "toolStripButton1";
            CmdSave.ToolTipText = "Guardar";
            CmdSave.Click += CmdSave_Click;
            // 
            // CmdOpen
            // 
            CmdOpen.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdOpen.Image = (Image)resources.GetObject("CmdOpen.Image");
            CmdOpen.ImageTransparentColor = Color.Magenta;
            CmdOpen.Name = "CmdOpen";
            CmdOpen.Size = new Size(29, 29);
            CmdOpen.Text = "toolStripButton2";
            CmdOpen.ToolTipText = "Abrir";
            CmdOpen.Click += CmdOpen_Click;
            // 
            // CmdExport
            // 
            CmdExport.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdExport.Image = Properties.Resources.Export;
            CmdExport.ImageTransparentColor = Color.Magenta;
            CmdExport.Name = "CmdExport";
            CmdExport.Size = new Size(29, 29);
            CmdExport.Text = "toolStripButton1";
            CmdExport.ToolTipText = "Exportar";
            CmdExport.Click += CmdExport_Click;
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(6, 32);
            // 
            // Añadir
            // 
            Añadir.DisplayStyle = ToolStripItemDisplayStyle.Image;
            Añadir.Image = Properties.Resources.add;
            Añadir.ImageTransparentColor = Color.Magenta;
            Añadir.Name = "Añadir";
            Añadir.Size = new Size(29, 29);
            Añadir.Text = "toolStripButton3";
            Añadir.Click += CmdAñadir_Click;
            // 
            // CmdBorrar
            // 
            CmdBorrar.DisplayStyle = ToolStripItemDisplayStyle.Image;
            CmdBorrar.Image = Properties.Resources.Borrar;
            CmdBorrar.ImageTransparentColor = Color.Magenta;
            CmdBorrar.Name = "CmdBorrar";
            CmdBorrar.Size = new Size(29, 29);
            CmdBorrar.Text = "Borrar todo";
            CmdBorrar.Click += CmdBorrar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(623, 45);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 17;
            label1.Text = "Altura";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(751, 45);
            label2.Name = "label2";
            label2.Size = new Size(34, 15);
            label2.TabIndex = 18;
            label2.Text = "Zona";
            // 
            // FrmComponentes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1005, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(toolStrip1);
            Controls.Add(PanComponentes);
            Controls.Add(LblPos);
            Controls.Add(LblSpeed);
            Controls.Add(LblVision);
            Controls.Add(LblPresion);
            Controls.Add(LblExplanation);
            Name = "FrmComponentes";
            Text = "Componentes";
            Load += FrmComponentes_Load;
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel PanComponentes;
        private Label LblExplanation;
        private Label LblPresion;
        private Label LblVision;
        private Label LblSpeed;
        private Label LblPos;
        private ToolStrip toolStrip1;
        private ToolStripButton CmdSave;
        private ToolStripButton CmdOpen;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripButton Añadir;
        private ToolStripButton CmdExport;
        private Label label1;
        private ToolStripButton CmdBorrar;
        private Label label2;
    }
}