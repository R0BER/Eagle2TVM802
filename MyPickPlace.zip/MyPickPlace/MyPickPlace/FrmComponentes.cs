﻿using MyPickPlace.Control.Componentes;
using MyPickPlace.UsuarioControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPickPlace
{
    public partial class FrmComponentes : Form
    {


        public FrmComponentes()
        {
            InitializeComponent();
        }
        public bool HaveChange { get; set; } = false;
        private void FrmComponentes_Load(object sender, EventArgs e)
        {
            PintarTodo();
        }
        private void PintarTodo()
        {
            PanComponentes.Controls.Clear();
            int p = 0;
            foreach (var c in ComponentesControl.Componentes)
            {
                PintaControl(c.Value, p);
                p++;
            }
        }
        private void PintaControl(Componente co, int position)
        {

            ListComponent listComponent = new ListComponent();
            listComponent.Iniciar(co);
            listComponent.Top = position * 30;
            PanComponentes.Controls.Add(listComponent);

            listComponent.Editar += EditarComponente;
            listComponent.Borrar += BorrarComponente;
        }
        private void BorrarComponente(Componente co)
        {
            if (ComponentesControl.Componentes.ContainsKey(co.StackNum))
            {
                ComponentesControl.Componentes.Remove(co.StackNum);
                PintarTodo();
            }

            HaveChange = true;
        }
        private void EditarComponente(Componente co)
        {
            FrmComponente f = new FrmComponente();
            f.componente = co;
            var r = f.ShowDialog();
            if (r == DialogResult.OK)
            {
                PintarTodo();
                HaveChange = true;
            }
        }



        private void CmdAñadir_Click(object sender, EventArgs e)
        {
            FrmComponente f = new FrmComponente();

            var r = f.ShowDialog();
            if (r == DialogResult.OK)
            {
                int P = ComponentesControl.Componentes.Count;
                ComponentesControl.AddComponente( f.componente);
                PintarTodo();
                HaveChange = true;
            }
        }

        private void CmdSave_Click(object sender, EventArgs e)
        {
            HaveChange = true;

            ComponentesControl.Guardar();
        }

        private void CmdOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            var r = f.ShowDialog();
            if (r == DialogResult.OK)
            {
                if (!f.FileName.ToUpper().EndsWith(".CSV"))
                {
                    MessageBox.Show("El archivo no es csv");
                    return;

                }
                string re = ComponentesControl.Cargar(f.FileName);
                PintarTodo();
                MessageBox.Show(re);
            }
        }

        private void CmdExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "csv files (*.csv)|*.csv";
            var r = f.ShowDialog();
            if (r == DialogResult.OK)
            {
                try
                {
                    File.Copy(ComponentesControl.RutaFile, f.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error guardando archivo");
                }
            }
        }

        private void LblSpeed_Click(object sender, EventArgs e)
        {

        }

        private void CmdBorrar_Click(object sender, EventArgs e)
        {
            var res = MessageBox.Show("Desea borrar todos los componentes", "Info", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                PanComponentes.Controls.Clear();
                ComponentesControl.Componentes.Clear();
                HaveChange = true;
            }

        }
    }
}
